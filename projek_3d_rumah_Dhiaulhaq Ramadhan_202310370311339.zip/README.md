# Rumah 3D Sederhana

Proyek ini membuat model 3D rumah menggunakan bentuk dasar:
- Kubus: untuk dinding dan pintu/jendela
- Silinder: cerobong asap
- Prisma segitiga (simulasi): atap

## Transformasi
- Translasi dan skala diterapkan untuk menyusun rumah
- Rotasi untuk kemiringan atap

## Jalankan
Buka `index.html` di browser untuk melihat model 3D interaktif.
