import numpy as np
import plotly.graph_objects as go

def create_cube(center, size):
    l = np.array(size) / 2
    x = np.array([-1, 1, 1, -1, -1, 1, 1, -1]) * l[0] + center[0]
    y = np.array([-1, -1, 1, 1, -1, -1, 1, 1]) * l[1] + center[1]
    z = np.array([-1, -1, -1, -1, 1, 1, 1, 1]) * l[2] + center[2]
    return go.Mesh3d(x=x, y=y, z=z, color='red', opacity=1)

def create_cylinder(center, radius, height):
    theta = np.linspace(0, 2*np.pi, 30)
    z = np.array([0, height])
    theta, z = np.meshgrid(theta, z)
    x = radius * np.cos(theta) + center[0]
    y = radius * np.sin(theta) + center[1]
    z = z + center[2]
    return go.Surface(x=x, y=y, z=z, colorscale=[[0, 'gray'], [1, 'gray']], showscale=False)

def create_roof():
    verts = np.array([
        [-2, -1, 2], [2, -1, 2], [0, -1, 3],
        [-2, 1, 2], [2, 1, 2], [0, 1, 3]
    ])
    x = [v[0] for v in verts]
    y = [v[1] for v in verts]
    z = [v[2] for v in verts]
    i = [0, 3]
    j = [1, 4]
    k = [2, 5]
    return go.Mesh3d(x=x, y=y, z=z, i=i, j=j, k=k, color='green', opacity=1)

def scene():
    parts = []
    parts.append(create_cube([0, 0, 1], [4, 2, 2]))
    parts.append(create_roof())
    parts.append(create_cylinder([-1.5, 0.8, 2], 0.2, 1))
    return parts

fig = go.Figure(data=scene())
fig.update_layout(scene=dict(aspectmode='data'))
import js
fig.show(renderer="plotly_mimetype+notebook_connected")
